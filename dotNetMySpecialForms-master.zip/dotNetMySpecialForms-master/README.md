<strong>dotNetMySpecialForms</strong> is my own version of everyday windows forms like About Box, Error Handler, Splash Screen and my base windows form
